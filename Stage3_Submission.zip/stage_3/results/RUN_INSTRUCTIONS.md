# Stage 3 submission essentials

This package contains the completed CNN implementation, all 36 trained models, all 15 graphs, three comparison tables, and supporting instructions/results explanations. It contains 60 files. The separate course report must still be prepared in the instructor's report template.

## Code and starter template

`stage3.py` is the single implementation file. It incorporates adapted versions of the instructor template's five base classes: `dataset`, `method`, `evaluate`, `result`, and `setting`, with the original copyright attribution retained. The concrete implementations are `Dataset_Loader`, `Method_CNN`, `Evaluate_Metrics`, `Result_Saver`, and `Setting_Predefined_Split`. Separate starter Python files are not required to execute it. These are adapted interfaces, not verbatim copies of every original template method.

## Included results

For each dataset (`MNIST`, `ORL`, `CIFAR`):

- `results/DATASET/comparison.csv`: measured comparison of all four configurations across three seeds, including means and sample standard deviations. Accuracy, precision, recall, and F1 values are fractions; multiply by 100 for percentages.
- `results/DATASET/figures/01_loss_vs_epoch.png`
- `results/DATASET/figures/02_accuracy_vs_epoch.png`
- `results/DATASET/figures/03_test_comparison.png`
- `results/DATASET/figures/04_confusion_matrices.png`
- `results/DATASET/figures/05_per_class_metrics.png`
- `results/DATASET/CONFIG/seed_N/model.pt`: final checkpoint for each configuration and seed.

Configurations: `A_baseline`, `B_deeper`, `C_average_pool`, `D_mse`. Seeds: 42, 43, 44. This gives 12 models per dataset, 36 total.

`REPORT_METRICS.md` explains the implementation and measured results. References there to detailed run outputs describe the full experiment archive; those detailed outputs are not included in this reduced package.

## Run the code

Use Python 3.12 and run these commands inside `stage_3/`:

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
```

Place the instructor-provided `MNIST`, `ORL`, and `CIFAR` files directly inside `data/`. See `data/ReadMe.txt` for their format. The large input datasets are not included in this package.

To run all experiments into a separate output folder and preserve the included results:

```bash
python stage3.py --output-dir rerun_results
```

Defaults use CPU, four threads, seeds 42/43/44, all four configurations, 10 epochs for MNIST/CIFAR, and 40 epochs for ORL. Retraining creates detailed histories, metrics, predictions, models, comparison tables, summaries, and graphs.

## Reduced-package limitation

The saved graphs and tables are ready to view. This package omits per-run `history.csv`, `metrics.json`, and `predictions.csv`, as well as summaries, verification records, logs, and checksums. Consequently, `--plots-only` cannot regenerate graphs directly from this package. Restore the detailed run files from the full GitHub results, or retrain first. The checkpoints contain final model weights and configuration, not optimizer state for resuming an interrupted epoch. No installer script is needed.
